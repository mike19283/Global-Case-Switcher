===================================================\
===============README FOR==========================
===============CASE CHANGER========================
==================V1.0=============================
===================================================
This takes whatever text was last on your clipboard (copy) and swaps case of every character. If something other than text was last on the clipboard, this application ignores it and displays an error if you continue anyways. Also, this application gives you a preview of text on the clipboard so you always know what you will paste. This toggles case, so if "Hello There!" is input, "hELLO tHERE! will be returned.